<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class AdminAuth extends Controller {

    public function __construct()
    {
        parent::__construct();
        if (isset($_SESSION['adminLogged'])) {
            redirect('admin_dashboard');
        }
    }

    public function index() {
        if ($this->form_validation->submitted()) {
            $this->form_validation->name('username')->required()->name('password')->required();

            if ($this->form_validation->run()) {
                $username = $this->io->post('username');
                $password = $this->io->post('password');
                $data = ['message' => 'Oops, Something went wrong.'];
                $verify = $this->db->table('admin')->where('username', $username)->get();

                if ($verify) {
                    if ($password == $verify['password']) {
                        $this->session->set_userdata('adminLogged', $verify['username']);
                        $this->set_flash_alert('success', 'Start your day with positive energy');
                        return redirect('admin_dashboard');
                    } else {
                        $this->set_flash_alert('error', 'Wrong input password.');
                    }
                } else {
                    $this->set_flash_alert('error', 'Account doesn\'t exist');
                }
            }
            $this->call->view('admin/login', $data);
        }
        $this->call->view('admin/login');
    }

    // Define the set_flash_alert function here
    private function set_flash_alert($type, $message) {
        $_SESSION['flash_alert'] = ['type' => $type, 'message' => $message];
    }
}
?>
