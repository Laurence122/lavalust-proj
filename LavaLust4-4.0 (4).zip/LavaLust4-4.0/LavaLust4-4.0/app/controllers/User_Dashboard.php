<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class User_Dashboard extends Controller {
    public function __construct()
    {
        parent::__construct();
        if(!isset($_SESSION['isLoggedIn'])){
            $this->set_flash_alert('danger', 'You need to be logged in to access this area.');
            return redirect('auth/login');
        }   
    }

    public function index() {
        $session = $this->session->userdata('isLoggedIn');
        $profile = $this->db->table('user')->where('id', $session)->get();
        $data = [
            'appt' => $this->db->table('appointments')->where('user_id', $session)->not_where('status', 'CANCELLED')->get_all(),
            'appt1' => $this->db->table('appointments')->where('user_id', $session)->get_all(),
            'name' => $profile['username'],
            'email' => $profile['email']
        ];
        $this->call->view('user/dashboard', $data);
    }

    public function cancel($id){
        $appt = $this->db->table('appointments')->where('id', $id)->get();

        if($appt['status'] == 'PENDING' or $appt['status'] == 'ACCEPTED'){
            $newstatus = 'CANCELLED';
        }
        $data = ['status' => $newstatus];

        $this->db->table('appointments')->where('id', $id)->update($data);
        $this->set_flash_alert('success', 'Appointment has been cancelled.');
        return redirect('user_dashboard');
    }

    public function appointment() {
        if($this->form_validation->submitted()){
            $this->form_validation
                ->name('firstname')->required()->name('lastname')->required()
                ->name('number')->required()->name('treatment')->required()
                ->name('datetime')->required();

            if($this->form_validation->run()){
                $session = $this->session->userdata('isLoggedIn');
                $data = [
                    'user_id'   => $session,
                    'firstname' => $this->io->post('firstname'),
                    'lastname'  => $this->io->post('lastname'),
                    'number'    => $this->io->post('number'),
                    'treatment' => $this->io->post('treatment'),
                    'datetime'  => $this->io->post('datetime'),
                    'status'    => 'PENDING'
                ];
                $this->db->table('appointments')->insert($data);
                $this->set_flash_alert('success', 'Your submission has been sent.');
                return redirect('user_dashboard');
            }
        }
        $this->call->view('user/appointment');
    }

    public function change_password(){
        $session = $this->session->userdata('isLoggedIn');
        if($this->form_validation->submitted()) {
            $password = $this->io->post('password');
            $newpassword = $this->io->post('newpassword');
            $this->form_validation
                ->name('password')->required()
                ->name('newpassword')->required()->min_length(8, 'Password must not be less than 8 characters.')
                ->name('renewpassword')->required()->min_length(8, 'Password must not be less than 8 characters.')
                ->matches('newpassword', 'Confirm password did not match.');

            if($this->form_validation->run()){
                $acc = $this->db->table('user')->where('id', $session)->get();
                $verifyPass = password_verify($password, $acc['password']);
                if($verifyPass){
                    $data = ['password' => password_hash($newpassword, PASSWORD_BCRYPT)];
                    $this->db->table('user')->where('id', $session)->update($data);
                    $this->set_flash_alert('success', 'Password changed successfully.');
                } else {
                    $this->set_flash_alert('danger', 'Wrong input password.');
                }
            } else {
                $this->set_flash_alert('danger', $this->form_validation->errors());
            }
            return redirect('user_dashboard/change_password');
        }
        
        $profile = $this->db->table('user')->where('id', $session)->get();
        $data = [
            'name' => $profile['username'],
            'email' => $profile['email']
        ];
        $this->call->view('user/changepassword', $data);
    }

    public function logout(){
        unset($_SESSION['isLoggedIn']);
        $this->set_flash_alert('success', 'You have been successfully logged out.');
        return redirect('auth/login');
    }

    private function set_flash_alert($type, $message) {
        $_SESSION['flash_alert'] = ['type' => $type, 'message' => $message];
    }
}
?>
