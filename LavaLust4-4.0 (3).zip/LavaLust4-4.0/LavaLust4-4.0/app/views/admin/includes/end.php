
<script src="<?= base_url()?>public/admin-assets/js/jquery-3.2.1.min.js"></script>
<!-- Bootstrap Core JS -->
<script src="<?= base_url()?>public/admin-assets/js/popper.min.js"></script>
<script src="<?= base_url()?>public/admin-assets/js/bootstrap.min.js"></script>
<!-- Slimscroll JS -->
<script src="<?= base_url()?>public/admin-assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?= base_url()?>public/admin-ssets/plugins/raphael/raphael.min.js"></script>    
<script src="<?= base_url()?>public/admin-assets/plugins/morris/morris.min.js"></script>  
<script src="<?= base_url()?>public/admin-assets/js/chart.morris.js"></script>	
<!-- Custom JS -->
<script  src="<?= base_url()?>public/admin-assets/js/script.js"></script>  