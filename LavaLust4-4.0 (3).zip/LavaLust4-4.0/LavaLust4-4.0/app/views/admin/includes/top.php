<!-- Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="<?= base_url()?>public/admin-assets/img/favicon.png">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?= base_url()?>public/admin-assets/css/bootstrap.min.css">
<!-- Fontawesome CSS -->
<link rel="stylesheet" href="<?= base_url()?>public/admin-assets/css/font-awesome.min.css">
<!-- Feathericon CSS -->
<link rel="stylesheet" href="<?= base_url()?>public/admin-assets/css/feathericon.min.css">
<link rel="stylesheet" href="<?= base_url()?>public/admin-assets/plugins/morris/morris.css">
<!-- Main CSS -->
<link rel="stylesheet" href="<?= base_url()?>public/admin-assets/css/style.css">
<!-- Select2 CSS -->
<link rel="stylesheet" href="<?= base_url()?>public/admin-assets/css/select2.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<!-- Datatables CSS -->
<link rel="stylesheet" href="<?= base_url()?>public/admin-assets/plugins/datatables/datatables.min.css">
<link rel="stylesheet" type="text/css" href="<?= base_url()?>public/jquery-datetimepicker/jquery.datetimepicker.css"/ >
<script src="<?= base_url()?>public/jquery-datetimepicker/jquery.js"></script>
<script src="<?= base_url()?>public/jquery-datetimepicker/build/jquery.datetimepicker.full.min.js"></script>