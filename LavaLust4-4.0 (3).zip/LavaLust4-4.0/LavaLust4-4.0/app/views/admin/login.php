<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <?= $this->view('admin/includes/top')?>
    <title>Admin | Login</title>
</head>
<body>
    <?php $LAVA =& lava_instance();?>
    <!-- Main Wrapper -->
    <div class="main-wrapper login-body">
            <div class="login-wrapper">
            	<div class="container">
                	<div class="loginbox">
                    	<div class="login-left">
							<img class="img-fluid" src="<?=base_url()?>public/admin-assets/img/logo-white.png" alt="Logo">
                        </div>
                        <div class="login-right">
							<div class="login-right-wrap">
								<h1>Login</h1>
								<p class="account-subtitle">Access to our dashboard</p>
								<!-- Form -->
								<?php flash_alert();?>
								<form action="<?=site_url('adminauth') ?>" method="post">
									<div class="form-group">
										<input type="text" name="username" class="form-control floating" id="username" placeholder="Username" value="" required autocomplete="name">
									</div>
									<div class="form-group">
										<input type="password" name="password" class="form-control floating" placeholder="Password">
									</div>
									<div class="form-group">
										<button class="btn btn-primary btn-block" type="submit">Login</button>
									</div>
								</form>
								<!-- /Form -->
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?= $this->view('admin/includes/end')?>
		<!-- /Main Wrapper -->
    <?php $LAVA =& lava_instance();?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script>
		$(document).ready(function(){
            var text = "<?php echo $LAVA->session->flashdata('message');?>";
            var title = "<?php echo $message;?>";
            var icon = "<?php echo $LAVA->session->flashdata('alert');?>"
            <?php if($LAVA->session->flashdata('alert')):?>
			swal({
				title: title,
				text: text,
				icon: icon,
                timer:2000,
				button:false,
				});
			<?php endif;?>
		});
    </script>
</body>
</html>