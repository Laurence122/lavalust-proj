
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<?= $this->view('admin/includes/top')?>
	<title>Admin - Dashboard</title>
</head>

<body>

<div class="alert alert-<?= $_SESSION['flash_alert']['type']; ?>">
        <?= $_SESSION['flash_alert']['message']; ?>
    </div>
    <?php unset($_SESSION['flash_alert']); // Clear the flash alert after it is shown ?>
	<!-- Main Wrapper -->
	<div class="main-wrapper">

		<!-- Header -->
		<?= $this->view('admin/includes/header')?>
		
		<!-- /Header -->	

		<!-- Sidebar -->
        <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
                    <div id="sidebar-menu" class="sidebar-menu">
                        <ul>
                            <li class="menu-title"> 
                                <span>Main</span>
                            </li>
                            <li class="active"> 
                                <a href="<?= site_url('admin_dashboard')?>"><i class="fe fe-home"></i> <span>Dashboard</span></a>
                            </li>
                            <li> 
                                <a href="<?= site_url('admin_dashboard/schedule')?>"><i class="fe fe-layout"></i> <span>Schedules</span></a>
                            </li>
                            <li> 
                                <a href="<?= site_url('admin_dashboard/appointments')?>"><i class="fe fe-layout"></i> <span>Appointments</span></a>
                            </li>
                            <li> 
                                <a href="<?= site_url('admin_dashboard/patients')?>"><i class="fe fe-user"></i> <span>Users</span></a>
                            </li>
                            <li> 
                                <a href="<?= site_url('admin_dashboard/my_admin')?>"><i class="fe fe-users"></i> <span>Admin</span></a>
                            </li>
                            <li> 
                                <a href="<?= site_url('admin_dashboard/settings')?>"><i class="fe fe-vector"></i> <span>Settings</span></a>
                            </li>
                            <li>
                            <a href="<?= site_url('admin_dashboard/logout')?>"><i class="fe fe-warning"></i> <span>Logout</span></span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
		<!-- /Sidebar -->

		<!-- Page Wrapper -->
		<div class="page-wrapper">
			<div class="content container-fluid">			
				<!-- Page Header -->
				<div class="page-header">
					<div class="row">
						<div class="col-sm-12">
							<h3 class="page-title">Welcome Admin!</h3>
							<ul class="breadcrumb">
								<li class="breadcrumb-item active">Dashboard</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- /Page Header -->

				<div class="row">
					<div class="col-xl-3 col-sm-6 col-12">
						<div class="card">
							<div class="card-body">
								<div class="dash-widget-header">
									<span class="dash-widget-icon text-primary border-primary">
										<i class="fe fe-users"></i>
									</span>
									<div class="dash-count">
										<h3>1</h3>
									</div>
								</div>
								<div class="dash-widget-info">
									<h6 class="text-muted">Doctors</h6>					
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 col-12">
						<div class="card">
							<div class="card-body">
								<div class="dash-widget-header">
									<span class="dash-widget-icon text-success">
										<i class="fe fe-credit-card"></i>
									</span>
									<div class="dash-count">
										<h3><?php echo $patient['total_row'];?></h3>
									</div>
								</div>
								<div class="dash-widget-info">
									
									<h6 class="text-muted">Patients</h6>
									<div class="progress progress-sm">
										<div class="progress-bar bg-success w-25"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 col-12">
						<div class="card">
							<div class="card-body">
								<div class="dash-widget-header">
									<span class="dash-widget-icon text-danger border-danger">
										<i class="fe fe-money"></i>
									</span>
									<div class="dash-count">
										<h3><?php echo $appointments['total_row'];?></h3>
									</div>
								</div>
								<div class="dash-widget-info">
									
									<h6 class="text-muted">Appointments</h6>
									<div class="progress progress-sm">
										<div class="progress-bar bg-danger w-50"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 col-12">
						<div class="card">
							<div class="card-body">
								<div class="dash-widget-header">
									<span class="dash-widget-icon text-warning border-warning">
										<i class="fe fe-folder"></i>
									</span>
									<div class="dash-count">
										<h3><?php echo $admin['total_row'];?></h3>
									</div>
								</div>
								<div class="dash-widget-info">
									
									<h6 class="text-muted">Administrator</h6>
									<div class="progress progress-sm">
										<div class="progress-bar bg-warning w-25"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-lg-6">
					
						<!-- Sales Chart -->
						<div class="card card-chart">
							<div class="card-header">
								<h4 class="card-title">Revenue</h4>
							</div>
							<div class="card-body">
								<div id="morrisArea"></div>
							</div>
						</div>
						<!-- /Sales Chart -->
						
					</div>
					<div class="col-md-12 col-lg-6">
					
						<!-- Invoice Chart -->
						<div class="card card-chart">
							<div class="card-header">
								<h4 class="card-title">Status</h4>
							</div>
							<div class="card-body">
								<div id="morrisLine"></div>
							</div>
						</div>
						<!-- /Invoice Chart -->		
					</div>	
				</div>		
			</div>			
		</div>
		<!-- /Page Wrapper -->
	</div>
	<!-- /Main Wrapper -->

		<!-- jQuery -->
        <script src="<?= base_url()?>public/admin-assets/js/jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?= base_url()?>public/admin-assets/js/popper.min.js"></script>
        <script src="<?= base_url()?>public/admin-assets/js/bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
        <script src="<?= base_url()?>public/admin-assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
		
		<script src="<?= base_url()?>public/admin-assets/plugins/raphael/raphael.min.js"></script>    
		<script src="<?= base_url()?>public/admin-assets/plugins/morris/morris.min.js"></script>  
		<script src="<?= base_url()?>public/admin-assets/js/chart.morris.js"></script>
		<!-- Custom JS -->
		<script  src="<?= base_url()?>public/admin-assets/js/script.js"></script>

		<?php $LAVA =& lava_instance();?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script>
		$(document).ready(function(){
            var text = "<?php echo $LAVA->session->flashdata('message');?>";
            var icon = "<?php echo $LAVA->session->flashdata('alert');?>"
            <?php if($LAVA->session->flashdata('alert')):?>
			swal({
				title: 'Welcome!',
				text: text,
				icon: icon,
                timer:2000,
				button:false,
				});
			<?php endif;?>
		});
    </script>
</body>

<!-- Mirrored from dreamguys.co.in/demo/doccure/admin/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Nov 2019 04:12:34 GMT -->
</html>