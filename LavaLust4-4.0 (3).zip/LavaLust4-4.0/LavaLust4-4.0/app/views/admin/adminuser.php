<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from dreamguys.co.in/demo/doccure/admin/specialities.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Nov 2019 04:12:49 GMT -->
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Doccure - Specialities Page</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url()?>public/admin-assets/img/favicon.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?= base_url()?>public/admin-assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?= base_url()?>public/admin-assets/css/font-awesome.min.css">
		
		<!-- Feathericon CSS -->
        <link rel="stylesheet" href="<?= base_url()?>public/admin-assets/css/feathericon.min.css">
		
		<!-- Datatables CSS -->
		<link rel="stylesheet" href="<?= base_url()?>public/admin-assets/plugins/datatables/datatables.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?= base_url()?>public/admin-assets/css/style.css">
		
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <?= $this->view('admin/includes/header')?>
			<!-- /Header -->
			
			<!-- Sidebar -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
                    <div id="sidebar-menu" class="sidebar-menu">
                        <ul>
                            <li class="menu-title"> 
                                <span>Main</span>
                            </li>
                            <li> 
                                <a href="<?= site_url('admin_dashboard')?>"><i class="fe fe-home"></i> <span>Dashboard</span></a>
                            </li>
                            <li> 
                                <a href="<?= site_url('admin_dashboard/schedule')?>"><i class="fe fe-layout"></i> <span>Schedules</span></a>
                            </li>
                            <li> 
                                <a href="<?= site_url('admin_dashboard/appointments')?>"><i class="fe fe-layout"></i> <span>Appointments</span></a>
                            </li>
                            <li> 
                                <a href="<?= site_url('admin_dashboard/patients')?>"><i class="fe fe-user"></i> <span>Users</span></a>
                            </li>
                            <li class="active"> 
                                <a href="<?= site_url('admin_dashboard/my_admin')?>"><i class="fe fe-users"></i> <span>Admin</span></a>
                            </li>
                            <li> 
                                <a href="<?= site_url('admin_dashboard/settings')?>"><i class="fe fe-vector"></i> <span>Settings</span></a>
                            </li>
                            <li>
                            <a href="<?= site_url('admin_dashboard/logout')?>"><i class="fe fe-warning"></i> <span>Logout</span></span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-7 col-auto">
								<h3 class="page-title">Administrator</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
									<li class="breadcrumb-item active">Administrator</li>
								</ul>
							</div>
							<div class="col-sm-5 col">
								<a href="#Add_Specialities_details" data-toggle="modal" class="btn btn-primary float-right mt-2">Add</a>
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					<div class="row">
						<div class="col-sm-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table class="datatable table table-hover table-center mb-0">
											<thead>
												<tr>
													<th>Admin ID</th>
													<th>Specialities</th>
													<th class="text-right">Actions</th>
												</tr>
											</thead>
											<tbody>
												<?php foreach($admin as $user):?>
												<tr>
													<td>#SP00<?= $user['id'];?></td>
													<td><?= $user['username'];?></td>																							
													<td class="text-right">
														<div class="actions">
															<a href="<?= site_url('admin_dashboard/delete_admin/') . $user['id'];?>" class="btn btn-sm bg-danger-light">
																<i class="fe fe-trash"></i> Delete
															</a>
														</div>
													</td>
												</tr>
												<?php endforeach;?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>			
					</div>
				</div>			
			</div>
			<!-- /Page Wrapper -->
			
			
			<!-- Add Modal -->
			<div class="modal fade" id="Add_Specialities_details" aria-hidden="true" role="dialog">
				<div class="modal-dialog modal-dialog-centered" role="document" >
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title">Add Specialities</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<form action="<?= site_url('admin_dashboard/add_admin');?>" method="post">
								<div class="row form-row">
									<div class="col-12 col-sm-6">
										<div class="form-group">
											<label>Username</label>
											<input type="text" name="username"class="form-control">
										</div>
									</div>
									<div class="col-12 col-sm-6">
                                        <div class="form-group">
											<label>Password</label>
											<input type="text" name="password" class="form-control">
										</div>
									</div>
									
								</div>
								<button type="submit" class="btn btn-primary btn-block">Save Changes</button>
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- /ADD Modal -->
			
			<!-- Edit Details Modal -->
			<div class="modal fade" id="edit_specialities_details" aria-hidden="true" role="dialog">
				<div class="modal-dialog modal-dialog-centered" role="document" >
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title">Edit Specialities</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<form>
								<div class="row form-row">
									<div class="col-12 col-sm-6">
										<div class="form-group">
											<label>Specialities</label>
											<input type="text" class="form-control" value="Cardiology">
										</div>
									</div>
									<div class="col-12 col-sm-6">
										<div class="form-group">
											<label>Image</label>
											<input type="file"  class="form-control">
										</div>
									</div>
									
								</div>
								<button type="submit" class="btn btn-primary btn-block">Save Changes</button>
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- /Edit Details Modal -->
			
			<!-- Delete Modal -->
			<div class="modal fade" id="delete_modal" aria-hidden="true" role="dialog">
				<div class="modal-dialog modal-dialog-centered" role="document" >
					<div class="modal-content">
					<!--	<div class="modal-header">
							<h5 class="modal-title">Delete</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>-->
						<div class="modal-body">
							<div class="form-content p-2">
								<h4 class="modal-title">Delete</h4>
								<p class="mb-4">Are you sure want to delete?</p>
								<button type="button" class="btn btn-primary">Save </button>
								<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- /Delete Modal -->
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="<?= base_url()?>public/admin-assets/js/jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?= base_url()?>public/admin-assets/js/popper.min.js"></script>
        <script src="<?= base_url()?>public/admin-assets/js/bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
        <script src="<?= base_url()?>public/admin-assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
		
		<!-- Datatables JS -->
		<script src="<?= base_url()?>public/admin-assets/plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="<?= base_url()?>public/admin-assets/plugins/datatables/datatables.min.js"></script>
		
		<!-- Custom JS -->
		<script  src="<?= base_url()?>public/admin-assets/js/script.js"></script>

		<?php $LAVA =& lava_instance();?>
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<script>
			$(document).ready(function(){
				var text = "<?php echo $LAVA->session->flashdata('message');?>";
				var icon = "<?php echo $LAVA->session->flashdata('alert');?>"
				<?php if($LAVA->session->flashdata('alert') == 'error'):?>
				swal({
					title: 'Oops! something went wrong.',
					text: text,
					icon: icon,
					timer:2000,
					button:false,
					});
				<?php endif;?>
				<?php if($LAVA->session->flashdata('alert') == 'add'):?>
				swal({
					title: 'Lets welcome the new admin',
					text: text,
					icon: 'success',
					timer:2000,
					button:false,
					});
				<?php endif;?>

				<?php if($LAVA->session->flashdata('alert') == 'delete'):?>
				swal({
					title: 'Please send a goodbye',
					text: text,
					icon: 'success',
					timer:2000,
					button:false,
					});
				<?php endif;?>
			});
		</script>
    </body>

<!-- Mirrored from dreamguys.co.in/demo/doccure/admin/specialities.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Nov 2019 04:12:51 GMT -->
</html>