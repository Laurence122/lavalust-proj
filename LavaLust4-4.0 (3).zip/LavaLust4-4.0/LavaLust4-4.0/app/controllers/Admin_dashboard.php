<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class Admin_Dashboard extends Controller {
    

    public function __construct()
    {
        parent::__construct();
        if(!isset($_SESSION['adminLogged'])){
            set_flash_alert('danger', 'You need to logged in to access this area.');
            return redirect('adminauth');
        }
    }

	public function index() {
        $data = [
            'admin' => $this->db->table('admin')->select_count('id' , 'total_row')->get(),
            'appointments' => $this->db->table('appointments')->select_count('id' , 'total_row')->get(),
            'patient' => $this->db->table('user')->select_count('id' , 'total_row')->get()
        ];
        $this->call->view('admin/index', $data);
	}

    public function schedule(){
        date_default_timezone_set("Asia/Manila");
        $today = date("Y/m/d 00:00");
        $tomorrow = date("Y/m/d 00:00",strtotime('+1 day' , strtotime($today)));
        $tomorrow1 = date("Y/m/d 00:00",strtotime('+1 day' , strtotime($tomorrow)));

        $data = [
            'today'     => $this->db->table('appointments')->where('datetime > ? AND datetime < ?', [$today, $tomorrow])->get_all(),
            'tomorrow'  => $this->db->table('appointments')->where('datetime > ? AND datetime < ?', [$tomorrow, $tomorrow1])->get_all(),
            'upcoming'  => $this->db->table('appointments')->where('datetime > ?', [$tomorrow])->get_all()
        ];

        $this->call->view('admin/schedule', $data);    
    }

    public function appointments(){
        $data['appt'] = $this->db->table('appointments')->get_all();
        $this->call->view('admin/appointments', $data);
    }

    public function cancel($id){
        $appt = $this->db->table('appointments')->where('id', $id)->get();

        if($appt['status'] == 'PENDING' or $appt['status'] == 'ACCEPTED'){
            $newstatus = 'CANCELLED';
        }
        $data = ['status' => $newstatus];

        $this->db->table('appointments')->where('id', $id)->update($data);
        return redirect('admin_dashboard/schedule');    
    }

    public function accept($id){
        $appt = $this->db->table('appointments')->where('id', $id)->get();

        if($appt['status'] == 'PENDING'){
            $newstatus = 'ACCEPTED';
        }
        $data = ['status' => $newstatus];

        $this->db->table('appointments')->where('id', $id)->update($data);
        return redirect('admin_dashboard/schedule');   
    }

    public function patients(){
        $data['patients'] = $this->db->table('user')->get_all();
        $this->call->view('admin/patient', $data);
    }

    public function my_admin(){
        $data['admin'] = $this->db->table('admin')->get_all();
        $this->call->view('admin/adminuser', $data);
    }

    public function add_admin(){
        $session = $this->session->userdata('adminLogged');
        if($this->form_validation->submitted()) {
            if($session == 'admin') {
                $username = $this->io->post('username');
                $password = $this->io->post('password');
                $this->form_validation
                ->name('username')->is_unique('admin', 'username', $username, 'Username was already taken.')
                ->name('password')->required();

                if($this->form_validation->run()) {
                    $data = [
                        'username' => $username,
                        'password' => $password
                    ];

                    $this->db->table('admin')->insert($data);
                    set_flash_alert('add', 'Please guide our new administrator to our system.');
                    return redirect('admin_dashboard/my_admin');
                } else {
                    set_flash_alert('error', 'Username exist. We are excited to meet our new admin.');
                    return redirect('admin_dashboard/my_admin');
                }
            } else {
                set_flash_alert('error', 'You dont have permission to perform this action.');
                return redirect('admin_dashboard/my_admin');
            }
        }
        return redirect('admin_dashboard/my_admin');
    }

    public function delete_admin($id) {
        $session = $this->session->userdata('adminLogged');
        if($session == 'admin') {
            $this->db->table('admin')->where('id', $id)->delete();
            set_flash_alert('delete', 'The time we spent together was amazing.');
            return redirect('admin_dashboard/my_admin');
        } else {
            set_flash_alert('error', 'You dont have permission to perform this action.');
            return redirect('admin_dashboard/my_admin');
        }
    }

    public function settings() {
        if($this->form_validation->submitted()) {
            $input = [
                'subject_activation' => $this->io->post('activation'),
                'subject_forgot'     => $this->io->post('forgot'),
                'sender_email'       => $this->io->post('sender'),
                'reply_email'        => $this->io->post('reply')
            ];

            $this->form_validation
                ->name('activation')->required()->name('forgot')->required()
                ->name('sender')->required()->name('reply')->required();
            
            if($this->form_validation->run()) {
                $this->db->table('email')->update($input);
                set_flash_alert('success', 'Email configuration updated');
                return redirect('admin_dashboard/settings');
            } else {
                set_flash_alert('danger', 'Please provide valid informations.');
                return redirect('admin_dashboard/settings');
            }
        }

        $email = $this->db->table('email')->get();
        $data = [
            'activation' => $email['subject_activation'],
            'forgot' => $email['subject_forgot'],
            'sender' => $email['sender_email'],
            'reply' => $email['reply_email']
        ];
        $this->call->view('admin/settings', $data);
    }

    public function logout(){
        unset($_SESSION['adminLogged']);
        set_flash_alert('success', 'You have been successfully logged out.');
        return redirect('adminauth');
    }

    public function test(){
        $data = $this->session->userdata('adminLogged');
        echo $data;
    }

    private function set_flash_alert($type, $message) {
        $_SESSION['flash_alert'] = ['type' => $type, 'message' => $message];
}

?>